const primeRoutes = require("./primenumber");

const constructorMethod = (app) => {
  app.use("/", primeRoutes);

  app.use("*", (req, res) => {
    res.status(404).render("primenumber/errors", {
      code: 404,
      description: "Page Not found",
    });
  });
};

module.exports = constructorMethod;
