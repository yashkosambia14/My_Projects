const primenumberChecker = (input) => {
  if (!input) {
    throw "Please enter a number!, it cannot be empty spaces";
  }
  if (isNaN(input) || !isFinite(input)) throw "Please enter a number!";
  var decimal = /^[-+]?[0-9]+\.[0-9]+$/;
  var negativeNumber = /^-\d*\.?\d+$/;
  if (input.match(decimal)) throw "use whole numbers!";
  if (input.match(negativeNumber)) throw "use positive whole number!";
  if (input <= 1) return false;
  if (input === 2) return true;
  let number = Math.sqrt(input);
  for (let i = 2; i <= number; i++) {
    //count = 0;
    if (input % i == 0) return false;
  }
  return true;
};

const formElement = document.getElementById("primeForm");
const input_num = document.getElementById("Input");
const ulDiv = document.getElementById("primeAttempts");
const ol = document.getElementById("attempts");
const errorDiv = document.getElementById("errorDiv");

formElement.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    input_num.classList.remove("errorsExists");
    errorDiv.classList.add("hidden");

    const input_num_value = input_num.value; //+ " is a prime number";

    const input_value = document.createTextNode(input_num_value);
    let isPrime = primenumberChecker(input_num_value);
    ulDiv.className = "primeAttempts";
    input_num.value = "";

    li = document.createElement("li");
    my_ans = [input_num_value + " is a prime number"];
    my_ans_2 = [input_num_value + " is NOT a prime number"];

    //my_ans = my_ans.toString();
    my_anus = document.createTextNode(my_ans);
    my_anus2 = document.createTextNode(my_ans_2);

    if (isPrime) {
      li.className = "is-prime";
      li.appendChild(my_anus);
    } else {
      li.className = "not-prime";
      li.appendChild(my_anus2);
    }

    ol.insertBefore(li, ol.childNodes[0]);
  } catch (e) {
    errorDiv.textContent = e;
    errorDiv.classList.remove("hidden");
    input_num.classList.add("errorsExists");
  }
});
